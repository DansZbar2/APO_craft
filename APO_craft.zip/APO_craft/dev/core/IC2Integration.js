var ICore = false;
ModAPI.addAPICallback("ICore", function(api){ 
    ICore = api;

});