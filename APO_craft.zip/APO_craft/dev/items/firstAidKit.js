IDRegistry.genItemID("firstAidKit");
Item.createItem("firstAidKit", "First Aid Kit", {name: "first_aid_kit", meta: 0}, {});
